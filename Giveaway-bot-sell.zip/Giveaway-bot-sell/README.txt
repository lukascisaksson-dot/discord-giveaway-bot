==================================================
   DISCORD GIVEAWAY BOT - SETUP GUIDE
==================================================

FEATURES:
- Interactive "Enter Giveaway" button with live entrant counter
- Admin-only "End Now" button to close early & pick a winner
- Auto-saving database (giveaways.json) - survives restarts!
- Role requirements & VIP/Booster bonus entry multipliers
- /giveaway reroll command

--------------------------------------------------
HOW TO SET UP (TAKES 3 MINUTES):
--------------------------------------------------

1. INSTALL NODE.JS
   - Download and install the LTS version from: https://nodejs.org/

2. CREATE YOUR DISCORD BOT
   - Go to: https://discord.com/developers/applications
   - Click "New Application" -> give it a name -> click "Create".
   - Copy your "Application ID" from the General Information tab.
   - Go to the "Bot" tab -> click "Reset Token" -> copy your Bot Token.
   - Scroll down to "Privileged Gateway Intents" and turn ON:
     [x] Server Members Intent
   - Click "Save Changes".

3. INVITE THE BOT TO YOUR SERVER
   - Go to "OAuth2" -> "URL Generator".
   - Check "bot" and "applications.commands".
   - Under Bot Permissions, check "Administrator" (or Manage Channels, Send Messages, Embed Links).
   - Copy the generated URL at the bottom, open it in your browser, and add the bot to your server.

4. CONFIGURE THE BOT
   - Open "config.json" in any text editor (Notepad or VS Code).
   - Paste your Bot Token and Application ID (clientId).
   - (Optional) Add your Host Role ID or VIP Bonus Role IDs.
   - Save the file.

5. START THE BOT
   - Open a terminal/command prompt inside this folder.
   - Run: npm install
   - Run: node index.js

COMMANDS:
- /giveaway start  -> Start a new giveaway
- /giveaway reroll -> Pick a new winner using the giveaway Message ID
